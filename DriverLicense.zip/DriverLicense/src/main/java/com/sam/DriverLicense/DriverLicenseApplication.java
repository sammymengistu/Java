package com.sam.DriverLicense;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DriverLicenseApplication {

	public static void main(String[] args) {
		SpringApplication.run(DriverLicenseApplication.class, args);
	}
}
